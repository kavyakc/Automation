package developer;

import common.setup.BotNavigationSetup;
import common.util.CommonUtils;
import common.util.SeleniumUtils;
import constants.CloudFunctionConstants;
import constants.GeneralConfigConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestDeveloperTabNavigation extends BotNavigationSetup {

    /**
     * This test is meant for testing the navigation to Developer Tab. This can be disabled as for every test case that requires
     * developer navigation is performed using the DeveloperNavigationSetup
     */
    @Test (enabled = false)
    public void testNavigationToDeveloperTab() {

        Reporter.log("Executing testcase:  testNavigationToDeveloperTab", true);
        CommonUtils.navigateToDeveloperTab(driver);
        SeleniumUtils.waitForElementLoadById(driver, CloudFunctionConstants.NEW_FUNC_BUTTON_ID);

    }
}
