package developer;

import common.setup.DeveloperNavigationSetup;
import common.util.SeleniumUtils;
import constants.CloudFunctionConstants;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.assertEquals;

public class TestCloudFunctions extends DeveloperNavigationSetup {

    /*TODO: Before navigating to the developer tab, go to config tab, add a bot title, and then change cloud functions version to V1.
           Otherwise the cloud functions test cases won't work'. Add this code in the DeveloperNavigationSetup class*/

    public static String DUMMY_FUNCTION_NAME = "automatedTestFunction";

    @Test(priority = 1)
    public void testFunctionCreation() {

        Reporter.log("Executing testcase:  testFunctionCreation", true);
        DeveloperUtils.createNewDummyFunction(driver, DUMMY_FUNCTION_NAME);

        boolean flag = validateFunctionExistence();
        assertEquals(flag, true, "Function could not be created. ");
    }

    @Test(priority = 2)
    public void testFunctionDeletion() throws InterruptedException {

        Reporter.log("Executing testcase:  testFunctionDeletion", true);

        boolean functionFoundFlag = false;

        SeleniumUtils.waitForImplicitPageLoad(driver, 10);
        List<WebElement> functionRecordList = driver.findElements(By.id(CloudFunctionConstants.FUNC_RECORD_ID));

        if (functionRecordList.size() > 0) {
            for (WebElement functionRecord : functionRecordList) {
                if (StringUtils.equals(functionRecord.getText(), DUMMY_FUNCTION_NAME)) {
                    functionFoundFlag = true;
                    try {
                        clickDeleteIcon(functionRecord);
                    } catch (InterruptedException e) {
                        //TODO: Add some logs
                    }
                    List<WebElement> buttonList = DeveloperUtils.getButtonList(driver);
                    DeveloperUtils.clickOKButton(buttonList);
                    Thread.sleep(2000);
                    //SeleniumUtils.waitForImplicitPageLoad(driver, 20);
                    SeleniumUtils.refreshUrl(driver);
                    SeleniumUtils.waitForImplicitPageLoad(driver, 20);
                    break;
                }
            }

            if (functionFoundFlag == false) {
                Assert.fail("Dummy function to be deleted is not found");
            }

        } else {
            Assert.fail("No functions found to be deleted.");
        }


        boolean flag = validateFunctionExistence();
        assertEquals(flag, false);

    }

    private boolean validateFunctionExistence() {
        List<WebElement> webElementList = driver.findElements(By.id(CloudFunctionConstants.FUNC_RECORD_ID));

        boolean flag = false;
        if (webElementList.size() > 0) {
            for (WebElement webElement : webElementList) {
                if (StringUtils.equals(webElement.getText(), DUMMY_FUNCTION_NAME)) {
                    flag = true;
                    break;
                }
            }
        }
        return flag;
    }


    private void clickDeleteIcon(WebElement functionRecord) throws InterruptedException {
        functionRecord.click();
        Thread.sleep(2000);
        SeleniumUtils.waitForElementLoadById(driver, CloudFunctionConstants.DEL_FUNC_BUTTON_ID);
        driver.findElement(By.id(CloudFunctionConstants.DEL_FUNC_BUTTON_ID)).click();
        Thread.sleep(1200);
    }

}
