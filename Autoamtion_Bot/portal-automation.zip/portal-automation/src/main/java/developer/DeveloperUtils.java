package developer;

import common.util.SeleniumUtils;
import constants.CloudFunctionConstants;
import constants.HTMLConstants;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class DeveloperUtils {

    public static void createNewDummyFunction(WebDriver driver, String dummyFunctionName) {

        driver.findElement(By.id(CloudFunctionConstants.NEW_FUNC_BUTTON_ID)).click();
        driver.findElement(By.id(CloudFunctionConstants.NEW_FUNC_NAME_ID)).sendKeys(dummyFunctionName);
        driver.findElement(By.id(CloudFunctionConstants.CREATE_FUNC_BUTTON_ID)).click();

        SeleniumUtils.waitForImplicitPageLoad(driver, 30);
        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForImplicitPageLoad(driver, 30);

    }

    public static List<WebElement> getButtonList(WebDriver driver) {

        return driver.findElements(By.cssSelector(HTMLConstants.BUTTON));
    }

    public static void clickOKButton(List<WebElement> buttonList) {
        for (WebElement button : buttonList) {
            if (StringUtils.equals(button.findElement(By.cssSelector(HTMLConstants.SPAN)).getText(), HTMLConstants.OK_TEXT)) {
                button.click();
                break;
            }
        }
    }
}
