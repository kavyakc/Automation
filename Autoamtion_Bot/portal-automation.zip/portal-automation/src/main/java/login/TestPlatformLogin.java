package login;

import common.setup.BrowserSetup;
import common.util.SeleniumUtils;
import constants.GlobalConstants;
import constants.HomePageConstants;
import constants.LoginConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.assertEquals;

public class TestPlatformLogin extends BrowserSetup {

    /**
     * This test is meant to check that the login is working as expected when valid credentials are provided
     */
    @Test(priority = 2)
    public void testLoginWithValidCredentials() {

        Reporter.log("Executing testcase:  testLoginWithValidCredentials", true);

        driver.get(GlobalConstants.YM_APP_URL);
        SeleniumUtils.waitForElementLoadById(driver, LoginConstants.LOGIN_BUTTON_ID);

        driver.findElement(By.id(LoginConstants.USERNAME_ID)).sendKeys(LoginConstants.VALID_USERNAME);
        driver.findElement(By.id(LoginConstants.PASSWORD_ID)).sendKeys(LoginConstants.VALID_PASSWORD);
        driver.findElement(By.id(LoginConstants.LOGIN_BUTTON_ID)).click();

        SeleniumUtils.waitForElementLoadById(driver, HomePageConstants.CREATE_BOT_ID);

        List<WebElement> dynamicElement = driver.findElements(By.id(HomePageConstants.CREATE_BOT_ID));
        assertEquals(dynamicElement.size(), 1);

    }


    /**
     * This test is meant to check that the login is failing when invalid credentials are provided
     */
    @Test(priority = 1)
    public void testLoginWithInvalidCredentials() {

        Reporter.log("Executing testcase:  testLoginWithInvalidCredentials", true);

        driver.get(GlobalConstants.YM_APP_URL);
        SeleniumUtils.waitForElementLoadById(driver, LoginConstants.LOGIN_BUTTON_ID);

        driver.findElement(By.id(LoginConstants.USERNAME_ID)).sendKeys(LoginConstants.INVALID_USERNAME);
        driver.findElement(By.id(LoginConstants.PASSWORD_ID)).sendKeys(LoginConstants.INVALID_PASSWORD);
        driver.findElement(By.id(LoginConstants.LOGIN_BUTTON_ID)).click();

        assertEquals(driver.getTitle(), LoginConstants.LOGIN_PAGE_TITLE);
        List<WebElement> dynamicElement = driver.findElements(By.id(LoginConstants.LOGIN_BUTTON_ID));
        assertEquals(dynamicElement.size(), 1);

    }


}
