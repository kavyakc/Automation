package common.util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class SeleniumUtils {

    public static void waitForElementLoadByClassName(WebDriver driver, String className) {
        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(className)));
    }

    public static void waitForElementLoadByClassName(WebDriver driver, String className, int waitTime) {
        WebDriverWait wait = new WebDriverWait(driver, waitTime);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(className)));
    }

    public static void waitForElementLoadById(WebDriver driver, String id) {
        WebDriverWait wait = new WebDriverWait(driver, 40);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
    }

    public static void waitForElementLoadById(WebDriver driver, String id, int waitTime) {
        WebDriverWait wait = new WebDriverWait(driver, waitTime);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
    }

    public static void waitForPageLoadByTitle(WebDriver driver, String title) {
        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.titleContains(title));
    }

    public static void waitForElementLoadByXPath(WebDriver driver, String xpath) {
        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
    }

    public static void waitForImplicitPageLoad(WebDriver driver, int timeInSeconds) {
        driver.manage().timeouts().implicitlyWait(timeInSeconds, TimeUnit.SECONDS);
    }

    public static void refreshUrl(WebDriver driver) {
        driver.navigate().refresh();
    }

    public static void navigateBack(WebDriver driver) {
        driver.navigate().back();
    }


    public static void findElementByID(WebDriver driver, String id) {
        //TODO: ADD implementation and use
    }

}
