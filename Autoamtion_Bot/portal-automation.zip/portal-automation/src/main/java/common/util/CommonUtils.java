package common.util;

import constants.GlobalConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CommonUtils {

    public static void navigateToDeveloperTab(WebDriver driver) {
        driver.findElement(By.xpath(GlobalConstants.DEVELOPER_TAB_XPATH)).click();
    }

    public static void navigateToIntelligenceTab(WebDriver driver) {
        driver.findElement(By.xpath(GlobalConstants.INTELLIGENCE_TAB_XPATH)).click();
    }

    public static void navigateToConfigurationTab(WebDriver driver) {
        driver.findElement(By.xpath(GlobalConstants.CONFIGURATION_TAB_XPATH)).click();
    }
}
