package common.util;

import java.util.Properties;

/**
 * This is the class meant for loading/extracting all the properties present the config file for use in the code using constants
 */
public final class PropertyUtils {

    public static final String CONFIG_FILENAME = "config.properties";
    private Properties properties = null;
    private static PropertyUtils instance = null;

    private PropertyUtils() {
        this.properties = new Properties();
        try {
            properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(CONFIG_FILENAME));
        } catch (Exception ex) {
            //TODO: Put exception message across
        }
    }

    private synchronized static void createInstance() {
        if (instance == null) {
            instance = new PropertyUtils();
        }
    }

    public static PropertyUtils getInstance() {
        if (instance == null) {
            createInstance();
        }
        return instance;
    }


    public String getProperty(String key) {
        String result = null;
        if (key != null && !key.trim().isEmpty()) {
            result = this.properties.getProperty(key);
        }
        return result;
    }


    public Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }

    public static String extractProperty(String propFileConst) {
        return PropertyUtils.getInstance().getProperty(propFileConst);
    }

}
