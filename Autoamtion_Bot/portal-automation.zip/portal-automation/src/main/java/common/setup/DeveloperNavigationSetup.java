package common.setup;

import common.util.CommonUtils;
import common.util.SeleniumUtils;
import constants.CloudFunctionConstants;
import constants.GeneralConfigConstants;
import constants.JourneysPageConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;

public class DeveloperNavigationSetup extends BotNavigationSetup {

    public static final String DEVELOPER_PAGE_IDENTIFICATION = "developer";
    public static final String BOT_TITLE = "Test Bot";

    @BeforeClass
    public void navigateToDeveloperTab() {

        if (!driver.getCurrentUrl().contains(DEVELOPER_PAGE_IDENTIFICATION)) {

            Reporter.log(">> Before navigating to Developer Tab, performing some required configuration: " +
                    "[Setting cloud function version]", true);
            setFunctionVersionConfig();

            Reporter.log(">> Navigating to Developer Tab", true);
            CommonUtils.navigateToDeveloperTab(driver);
            SeleniumUtils.waitForElementLoadById(driver, CloudFunctionConstants.NEW_FUNC_BUTTON_ID);
        } else {
            Reporter.log(">> Already in Developer tab, going for next step", true);
        }

    }

    /**
     * This is pre-requisite method is used to set the version of cloud functions to version1 so as the tests on cloud functions as designed to work on the version1 mode
     */
    private void setFunctionVersionConfig() {

        CommonUtils.navigateToConfigurationTab(driver);
        SeleniumUtils.waitForElementLoadById(driver, GeneralConfigConstants.BOT_TITLE_ID,20);

        WebElement botTitle = driver.findElement(By.id(GeneralConfigConstants.BOT_TITLE_ID));
        botTitle.clear();
        botTitle.sendKeys(BOT_TITLE);

        WebElement functionVersionDropdown = driver.findElement(By.id(GeneralConfigConstants.CLOUD_FUNC_VER_DROPDOWN_ID));
        functionVersionDropdown.click();
        driver.findElement(By.id(GeneralConfigConstants.CLOUD_FUNC_VER_ONE_ID)).click();

        driver.findElement(By.id(GeneralConfigConstants.CONFIG_SAVE_SETTINGS_BUTTON_ID)).click();
        SeleniumUtils.waitForElementLoadById(driver,GeneralConfigConstants.BOT_TITLE_ID, 20);

        SeleniumUtils.navigateBack(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.CREATE_JOURNEY_BUTTON_ID);
    }
}
