package common.setup;

import common.util.CommonUtils;
import common.util.SeleniumUtils;
import constants.JourneysPageConstants;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;


public class IntelligenceNavigationSetup extends BotNavigationSetup {
    public static final String INTELLIGENCE_PAGE_IDENTIFICATION = "ai";

    @BeforeClass
    public void navigateToDeveloperTab() {

        if (!driver.getCurrentUrl().contains(INTELLIGENCE_PAGE_IDENTIFICATION)) {
            Reporter.log(">> Navigating to Intelligence Tab", true);
            CommonUtils.navigateToIntelligenceTab(driver);
            SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.BOT_NAME_ID);
        } else {
            Reporter.log(">> Already in Intelligence tab, going for next step", true);
        }
    }
}
