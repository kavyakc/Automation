package common.setup;

import common.util.SeleniumUtils;
import constants.GlobalConstants;
import constants.HTMLConstants;
import constants.HomePageConstants;
import constants.LoginConstants;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;

public class PlatformLoginSetup extends BrowserSetup {

    public static final String LOGIN_PAGE_IDENTIFICATION = "login";

    @BeforeClass
    public void loginToPlatform() {

        //driver.manage().deleteAllCookies(); //enable this if fresh login is required for every action bot
        if (!driver.getCurrentUrl().contains(LOGIN_PAGE_IDENTIFICATION)
         && !StringUtils.equals(driver.getCurrentUrl(), HTMLConstants.ABOUT_BLANK)
                && !StringUtils.equals(driver.getCurrentUrl(), "data:,")) {
            Reporter.log(">> Already logged in, going for next step", true);
        } else {
            loginUsingCredentials();
        }
    }

    private void loginUsingCredentials() {
        SeleniumUtils.waitForImplicitPageLoad(driver, 10);

        Reporter.log(">> Logging in to the platform", true);

        driver.get(GlobalConstants.YM_APP_URL);
        SeleniumUtils.waitForElementLoadById(driver, LoginConstants.LOGIN_BUTTON_ID);

        driver.findElement(By.id(LoginConstants.USERNAME_ID)).sendKeys(LoginConstants.VALID_USERNAME);
        driver.findElement(By.id(LoginConstants.PASSWORD_ID)).sendKeys(LoginConstants.VALID_PASSWORD);
        driver.findElement(By.id(LoginConstants.LOGIN_BUTTON_ID)).click();

        SeleniumUtils.waitForElementLoadById(driver, HomePageConstants.CREATE_BOT_ID);
    }
}
