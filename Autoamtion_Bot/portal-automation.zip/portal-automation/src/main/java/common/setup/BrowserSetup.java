package common.setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.lang.reflect.Method;

public class BrowserSetup {

    public static WebDriver driver;

    @BeforeSuite(alwaysRun = true)
    public void setupBrowser() {
        Reporter.log(">> Browser Session Started", true);

        FirefoxBinary firefoxBinary = new FirefoxBinary();
        firefoxBinary.addCommandLineOptions("--headless");

        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setBinary(firefoxBinary);
        driver = new FirefoxDriver(firefoxOptions);

        //driver=new FirefoxDriver();

    }

    @AfterSuite(alwaysRun = true)
    public void closeBrowser() {
        driver.quit();
        Reporter.log(">> Browser Session Ended", true);

    }

    //Uncomment below methods if you need to log any statements before and after every method execution

/*

 @BeforeMethod
    public void beforeTestMethod(Method testMethod){
        System.out.println("Execution starting for method: " + testMethod.getName());
    }

    @AfterMethod
    public void afterTestMethod(Method testMethod){
        System.out.println("Execution ended for method: " + testMethod.getName());
    }
*/

}
