package common.setup;

import common.util.SeleniumUtils;
import constants.JourneysPageConstants;
import constants.GlobalConstants;
import constants.HomePageConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;

import java.util.List;

public class BotNavigationSetup extends PlatformLoginSetup {

    public static final String BOT_PAGE_IDENTIFICATION = "#/a";

    @BeforeClass
    public void navigateToBot() {

        if (driver.getCurrentUrl().contains(BOT_PAGE_IDENTIFICATION)) {
            Reporter.log(">> Already navigated to bot, going for next step", true);
        } else {
            Reporter.log(">> Navigating to a Bot", true);
            findBotAndNavigate();
        }
    }

    private void findBotAndNavigate() {
        SeleniumUtils.waitForElementLoadByClassName(driver, HomePageConstants.BOT_NAV_LINK);
        List<WebElement> bots = driver.findElements(By.className(HomePageConstants.BOT_NAV_LINK));

        if (bots.size() != 0) {
            WebElement bot = bots.get(0);
            String botName = bot.getText();
            clickOnBot(botName);
            SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.BOT_NAME_ID);
            //SeleniumUtils.waitForElementLoadByXPath(driver, GlobalConstants.DEVELOPER_TAB_XPATH);
        } else {
            Reporter.log("No bots available to navigate to. Please consider having created a bot and then try executing this again!");
        }
    }

    private void clickOnBot(String botName) {
        driver.findElement(By.linkText(botName)).click();
    }

}
