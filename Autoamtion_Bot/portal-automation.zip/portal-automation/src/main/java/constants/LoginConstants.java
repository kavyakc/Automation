package constants;

import common.util.PropertyUtils;

public class LoginConstants {

    public static final String VALID_USERNAME = PropertyUtils.extractProperty(PropertyConstantMapping.VALID_USERNAME);
    public static final String VALID_PASSWORD = PropertyUtils.extractProperty(PropertyConstantMapping.VALID_PASSWORD);
    public static final String INVALID_USERNAME = PropertyUtils.extractProperty(PropertyConstantMapping.INVALID_USERNAME);
    public static final String INVALID_PASSWORD = PropertyUtils.extractProperty(PropertyConstantMapping.INVALID_PASSWORD);

    public static final String USERNAME_ID = PropertyUtils.extractProperty(PropertyConstantMapping.USERNAME_ID);
    public static final String PASSWORD_ID = PropertyUtils.extractProperty(PropertyConstantMapping.PASSWORD_ID);
    public static final String LOGIN_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.LOGIN_BUTTON_ID);

    public static final String LOGIN_PAGE_TITLE = PropertyUtils.extractProperty(PropertyConstantMapping.LOGIN_PAGE_TITLE);

}
