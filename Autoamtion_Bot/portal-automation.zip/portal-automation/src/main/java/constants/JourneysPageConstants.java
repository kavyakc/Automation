package constants;

import common.util.PropertyUtils;

public class JourneysPageConstants {

    public static final String BOT_NAME_ID = PropertyUtils.extractProperty(PropertyConstantMapping.BOT_NAME_ID);
    public static final String CREATE_JOURNEY_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CREATE_JOURNEY_BUTTON_ID);
    public static final String IMPORT_JOURNEY_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.IMPORT_JOURNEY_BUTTON_ID);
    public static final String JOURNEY_NAME_ID = PropertyUtils.extractProperty(PropertyConstantMapping.JOURNEY_NAME_ID);
    public static final String JOURNEY_DESC_ID = PropertyUtils.extractProperty(PropertyConstantMapping.JOURNEY_DESC_ID);
    public static final String  JOURNEY_CATEGORY_ID = PropertyUtils.extractProperty(PropertyConstantMapping.JOURNEY_CATEGORY_ID);
    public static final String JOURNEY_LINK_ID = PropertyUtils.extractProperty(PropertyConstantMapping.JOURNEY_LINK_ID);
    public static final String CREATE_CONFIRM_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CREATE_CONFIRM_BUTTON_ID);
    public static final String CATEGORY_LISTING_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CATEGORY_LISTING_BUTTON_ID);
    public static final String CATEGORY_LINK_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CATEGORY_LINK_ID);
    public static final String CATEGORY_NAME_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CATEGORY_NAME_ID);
    public static final String CATEGORY_ADD_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CATEGORY_ADD_BUTTON_ID);
    public static final String UTTERANCES_INPUT_ID = PropertyUtils.extractProperty(PropertyConstantMapping.UTTERANCES_INPUT_ID);
    public static final String UTTERANCE_RECORD_ID = PropertyUtils.extractProperty(PropertyConstantMapping.UTTERANCE_RECORD_ID);
    public static final String ADD_STEP_LINK_ID = PropertyUtils.extractProperty(PropertyConstantMapping.ADD_STEP_LINK_ID);
    public static final String STEP_NAME_ID = PropertyUtils.extractProperty(PropertyConstantMapping.STEP_NAME_ID);
    public static final String CREATE_STEP_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CREATE_STEP_BUTTON_ID);
    public static final String STEP_LIST_ID = PropertyUtils.extractProperty(PropertyConstantMapping.STEP_LIST_ID);
    public static final String JOURNEY_SETTINGS_LINK_ID = PropertyUtils.extractProperty(PropertyConstantMapping.JOURNEY_SETTINGS_LINK_ID);
    public static final String JOURNEY_DELETE_LINK_ID = PropertyUtils.extractProperty(PropertyConstantMapping.JOURNEY_DELETE_LINK_ID);
    public static final String CREATE_FUNC_NAV_LINK_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CREATE_FUNC_NAV_LINK_ID);
    public static final String INIT_FUNCTION_DROPDOWN_CLASS = PropertyUtils.extractProperty(PropertyConstantMapping.INIT_FUNCTION_DROPDOWN_CLASS);
    public static final String INIT_FUNCTION_OPTION_ID = PropertyUtils.extractProperty(PropertyConstantMapping.INIT_FUNCTION_OPTION_ID);
    public static final String RESPONSE_TIMELINE_CLASS = PropertyUtils.extractProperty(PropertyConstantMapping.RESPONSE_TIMELINE_CLASS);
    public static final String RESPONSE_TYPE_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.RESPONSE_TYPE_BUTTON_ID);
    public static final String FUNCTION_SELECT_DROPDOWN_CLASS = PropertyUtils.extractProperty(PropertyConstantMapping.FUNCTION_SELECT_DROPDOWN_CLASS);
    public static final String FUNCTION_OPTION_ID = PropertyUtils.extractProperty(PropertyConstantMapping.FUNCTION_OPTION_ID);

}
