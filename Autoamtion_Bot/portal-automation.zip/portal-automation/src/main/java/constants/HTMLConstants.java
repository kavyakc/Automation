package constants;

public class HTMLConstants {

    public static final String BUTTON = "button";
    public static final String SPAN = "span";
    public static final String OK_TEXT = "OK";
    public static final String ABOUT_BLANK = "about:blank";
    public static final String DIV = "div";
    public static final String ANCHOR = "a";
    public static final String INPUT = "input";
    public static final String VALUE = "value";

}
