package constants;

public class PropertyConstantMapping {

    public static final String VALID_USERNAME = "valid.username";
    public static final String VALID_PASSWORD = "valid.password";
    public static final String INVALID_USERNAME = "invalid.username";
    public static final String INVALID_PASSWORD = "invalid.password";

    public static final String USERNAME_ID = "username.id";
    public static final String PASSWORD_ID = "password.id";
    public static final String LOGIN_BUTTON_ID = "login.button.id";

    public static final String LOGIN_PAGE_TITLE = "login.page.title";
    public static final String YM_APP_URL = "ym.app.url";

    public static final String BOT_NAV_LINK = "bot.nav.link.class";
    public static final String CREATE_BOT_ID = "create.bot.id";

    public static final String BOT_NAME_ID = "bot.name.id";
    public static final String CREATE_JOURNEY_BUTTON_ID = "journey.create.button.id";
    public static final String IMPORT_JOURNEY_BUTTON_ID = "import.journey.button.id";
    public static final String JOURNEY_NAME_ID = "journey.name.id";
    public static final String JOURNEY_DESC_ID = "journey.desc.id";
    public static final String JOURNEY_CATEGORY_ID = "journey.category.id";
    public static final String JOURNEY_LINK_ID = "journey.link.id";
    public static final String CREATE_CONFIRM_BUTTON_ID = "create.journey.confirm";
    public static final String CATEGORY_LISTING_BUTTON_ID = "category.listing.button.id";
    public static final String CATEGORY_LINK_ID = "category.link.id";
    public static final String CATEGORY_NAME_ID = "category.name.id";
    public static final String CATEGORY_ADD_BUTTON_ID = "category.add.button.id";
    public static final String UTTERANCES_INPUT_ID = "utterances.input.id";
    public static final String UTTERANCE_RECORD_ID = "utterance.record.id";
    public static final String ADD_STEP_LINK_ID = "add.step.link.id";
    public static final String STEP_NAME_ID = "step.name.id";
    public static final String CREATE_STEP_BUTTON_ID = "create.step.button.id";
    public static final String STEP_LIST_ID = "steplist.id";
    public static final String JOURNEY_SETTINGS_LINK_ID = "journey.settings.link.id";
    public static final String JOURNEY_DELETE_LINK_ID = "journey.delete.link.id";
    public static final String CREATE_FUNC_NAV_LINK_ID = "function.create.nav.link.id";
    public static final String INIT_FUNCTION_DROPDOWN_CLASS = "init.func.dropdown.class";
    public static final String INIT_FUNCTION_OPTION_ID = "init.func.option.id";
    public static final String RESPONSE_TIMELINE_CLASS = "response.timeline.class";
    public static final String RESPONSE_TYPE_BUTTON_ID = "response.type.button.id";
    public static final String FUNCTION_SELECT_DROPDOWN_CLASS = "function.select.dropdown.class";
    public static final String FUNCTION_OPTION_ID = "function.option.id";

    public static final String DEVELOPER_TAB_XPATH = "developer.tab.xpath";
    public static final String NEW_FUNC_BUTTON_ID = "new.function.button.id";
    public static final String NEW_FUNC_NAME_ID = "new.func.name.id";
    public static final String CREATE_FUNC_BUTTON_ID = "create.func.button.id";
    public static final String FUNC_RECORD_ID = "function.record.id";
    public static final String DEL_FUNC_BUTTON_ID = "del.func.button.id";

    public static final String INTELLIGENCE_TAB_XPATH = "intelligence.tab.xpath";

    public static final String CONFIGURATION_TAB_XPATH = "configuration.tab.xpath";
    public static final String BOT_TITLE_ID = "bot.title.id";
    public static final String CLOUD_FUNC_VER_DROPDOWN_ID = "cloud.function.version.dropdown.id";
    public static final String CONFIG_SAVE_SETTINGS_BUTTON_ID = "config.save.settings.button.id";
    public static final String CLOUD_FUNC_VER_ONE_ID = "cloud.func.version.one.id";
    public static final String CLOUD_FUNC_VER_TWO_ID = "cloud.func.version.two.id";


}
