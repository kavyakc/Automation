package constants;

import common.util.PropertyUtils;

public class GlobalConstants {

    public static final String YM_APP_URL = PropertyUtils.extractProperty(PropertyConstantMapping.YM_APP_URL);

    public static final String DEVELOPER_TAB_XPATH = PropertyUtils.extractProperty(PropertyConstantMapping.DEVELOPER_TAB_XPATH);
    public static final String INTELLIGENCE_TAB_XPATH = PropertyUtils.extractProperty(PropertyConstantMapping.INTELLIGENCE_TAB_XPATH);
    public static final String CONFIGURATION_TAB_XPATH = PropertyUtils.extractProperty(PropertyConstantMapping.CONFIGURATION_TAB_XPATH);
}
