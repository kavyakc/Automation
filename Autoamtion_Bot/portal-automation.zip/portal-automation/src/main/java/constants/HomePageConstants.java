package constants;

import common.util.PropertyUtils;

public class HomePageConstants {

    public static final String BOT_NAV_LINK = PropertyUtils.extractProperty(PropertyConstantMapping.BOT_NAV_LINK);
    public static final String CREATE_BOT_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CREATE_BOT_ID);

}
