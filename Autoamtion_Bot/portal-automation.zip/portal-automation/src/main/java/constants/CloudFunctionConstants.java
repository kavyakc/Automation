package constants;

import common.util.PropertyUtils;

public class CloudFunctionConstants {

    public static final String NEW_FUNC_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.NEW_FUNC_BUTTON_ID);
    public static final String NEW_FUNC_NAME_ID = PropertyUtils.extractProperty(PropertyConstantMapping.NEW_FUNC_NAME_ID);
    public static final String CREATE_FUNC_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CREATE_FUNC_BUTTON_ID);
    public static final String FUNC_RECORD_ID = PropertyUtils.extractProperty(PropertyConstantMapping.FUNC_RECORD_ID);
    public static final String DEL_FUNC_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.DEL_FUNC_BUTTON_ID);
}
