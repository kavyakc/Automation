package constants;

import common.util.PropertyUtils;

public class GeneralConfigConstants {

    public static final String BOT_TITLE_ID = PropertyUtils.extractProperty(PropertyConstantMapping.BOT_TITLE_ID);
    public static final String CLOUD_FUNC_VER_DROPDOWN_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CLOUD_FUNC_VER_DROPDOWN_ID);
    public static final String CONFIG_SAVE_SETTINGS_BUTTON_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CONFIG_SAVE_SETTINGS_BUTTON_ID);
    public static final String CLOUD_FUNC_VER_ONE_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CLOUD_FUNC_VER_ONE_ID);
    public static final String CLOUD_FUNC_VER_TWO_ID = PropertyUtils.extractProperty(PropertyConstantMapping.CLOUD_FUNC_VER_TWO_ID);

}
