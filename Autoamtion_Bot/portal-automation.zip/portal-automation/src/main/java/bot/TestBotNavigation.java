package bot;

import common.setup.PlatformLoginSetup;
import common.util.SeleniumUtils;
import constants.JourneysPageConstants;
import constants.HomePageConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.assertEquals;

public class TestBotNavigation extends PlatformLoginSetup {

    /**
     * This test is meant for testing the navigation to Bot. This can be disabled as for every test case that requires
     * Bot navigation is performed using the BotNavigationSetup
     */
    @Test (enabled = false)
    public void testBotNavigation() {

        SeleniumUtils.waitForElementLoadByClassName(driver, HomePageConstants.BOT_NAV_LINK);

        Reporter.log("Executing testcase:  testBotNavigation", true);
        List<WebElement> bots = driver.findElements(By.className(HomePageConstants.BOT_NAV_LINK));

        if (bots.size() != 0) {
            WebElement bot = bots.get(0);
            String botName = bot.getText();
            navigateToBotWindow(botName);
            SeleniumUtils.waitForImplicitPageLoad(driver,30);
            String navigatedBotName = driver.findElement(By.id(JourneysPageConstants.BOT_NAME_ID)).getText();
            assertEquals(navigatedBotName,botName);
        }

    }

    private void navigateToBotWindow(String botName) {
        driver.findElement(By.linkText(botName)).click();
    }

}
