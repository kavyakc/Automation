package intelligence;

import common.setup.BotNavigationSetup;
import common.util.CommonUtils;
import common.util.SeleniumUtils;
import constants.JourneysPageConstants;
import org.testng.Reporter;
import org.testng.annotations.Test;


/**
 * This test is meant for testing the navigation to Intelligence tab. This can be disabled as for every test case that requires
 * Intelligence tab navigation is performed using the IntelligenceNavigationSetup
 */
public class TestIntelligenceTabNavigation extends BotNavigationSetup {

    @Test (enabled = false)
    public void testNavigationToIntelligenceTab() {
        Reporter.log("Executing testcase:  testNavigationToIntelligenceTab", true);
        CommonUtils.navigateToIntelligenceTab(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.BOT_NAME_ID);
    }

}
