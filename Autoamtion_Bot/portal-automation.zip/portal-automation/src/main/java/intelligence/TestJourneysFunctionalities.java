package intelligence;

import common.setup.BotNavigationSetup;
import common.setup.IntelligenceNavigationSetup;
import common.util.SeleniumUtils;
import constants.CloudFunctionConstants;
import constants.HTMLConstants;
import constants.JourneysPageConstants;
import developer.DeveloperUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;

import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class TestJourneysFunctionalities extends IntelligenceNavigationSetup {

    public static final String DUMMY_TEST_JOURNEY_NAME = "Property Management Journey";

    public static final String DUMMY_TEST_CUSTOM_CATEGORY_JOURNEY_NAME = "Ticket Booking";
    public static final String DUMMY_INIT_FUNCTION = "initFunction";

    /**
     * This test is meant for creating a journey within the default category
     */
    @Test(priority = 1)
    public void testJourneyCreationWithinDefaultCategory() {
        Reporter.log("Executing testcase:  testJourneyCreationWithinDefaultCategory", true);

        String journeyCategory = createJourneyAndReturnCategory(DUMMY_TEST_JOURNEY_NAME);
        boolean journeyFoundFlag = validateJourneyCreation(DUMMY_TEST_JOURNEY_NAME);

        assertEquals(journeyFoundFlag, true);
        assertEquals(journeyCategory, "Default Category");
    }

    /**
     * This test is meant for adding a new category of journey
     * @throws InterruptedException
     */
    @Test(priority = 2)
    public void testCategoryAddition() throws InterruptedException {
        Reporter.log("Executing testcase:  testCategoryAddition", true);

        boolean validationFlag = false;
        addCategory("ABC");

        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.CATEGORY_LISTING_BUTTON_ID);

        validationFlag = switchToCustomCategory("ABC");

        assertEquals(validationFlag, true);
    }

    /**
     * This test is meant for creating a journey within a custom/dummy category
     * @throws InterruptedException
     */
    @Test(priority = 3)
    public void testJourneyCreationWithinCustomCategory() throws InterruptedException {
        Reporter.log("Executing testcase:  testJourneyCreationWithinCustomCategory", true);

        SeleniumUtils.refreshUrl(driver);
        switchToCustomCategory("ABC");
        Thread.sleep(2000);

        String journeyCategory = createJourneyAndReturnCategory(DUMMY_TEST_CUSTOM_CATEGORY_JOURNEY_NAME);

        switchToCustomCategory("ABC");
        Thread.sleep(2000);
        boolean journeyFoundFlag = validateJourneyCreation(DUMMY_TEST_CUSTOM_CATEGORY_JOURNEY_NAME);

        assertEquals(journeyFoundFlag, true);
        assertEquals(journeyCategory, "ABC");

    }

    /**
     * This test is meant for adding few utterances to the custom journey
     * @throws InterruptedException
     */
    @Test(priority = 4)
    public void testUtterancesAddition() throws InterruptedException {

        //TODO: Add logs when journey does not exist

        Reporter.log("Executing testcase:  testUtterancesAddition", true);

        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadByClassName(driver, JourneysPageConstants.JOURNEY_LINK_ID,30);
        switchToCustomJourney();

        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.UTTERANCES_INPUT_ID, 30);

        String utterance1 = "land management";
        String utterance2 = "real estate";

        driver.findElement(By.id(JourneysPageConstants.UTTERANCES_INPUT_ID)).sendKeys(utterance1);
        driver.findElement(By.id(JourneysPageConstants.UTTERANCES_INPUT_ID)).sendKeys(Keys.ENTER);
        Thread.sleep(2000);
        driver.findElement(By.id(JourneysPageConstants.UTTERANCES_INPUT_ID)).sendKeys(utterance2);
        driver.findElement(By.id(JourneysPageConstants.UTTERANCES_INPUT_ID)).sendKeys(Keys.ENTER);

        Thread.sleep(2000);
        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.UTTERANCE_RECORD_ID, 40);

        List<WebElement> utteranceList = driver.findElements(By.id(JourneysPageConstants.UTTERANCE_RECORD_ID));

        //Checking if the utterances are output properly // Might remove this
        boolean flag = false;
        for (WebElement utterance : utteranceList) {
            if (StringUtils.equals(utterance.getText(), utterance1) || StringUtils.equals(utterance.getText(), utterance2)) {
                flag = true;
                break;
            }
        }

        assertTrue(utteranceList.size() > 0);
        assertEquals(flag, true);

    }

    //Use the below code when you want to execute the test case individually.
    // Otherwise not needed since it will be executed after the previous testcase where it already will be in custom journey page

        /*
            SeleniumUtils.waitForElementLoadById(driver,JourneysPageConstants.CREATE_JOURNEY_BUTTON_ID);
            switchToCustomJourney();
         */

    /**
     * This test is meant for adding few steps to the custom journey
     * @throws InterruptedException
     */
    @Test(priority = 5)
    public void testStepsAddition() throws InterruptedException {
        Reporter.log("Executing testcase:  testStepsAddition", true);

        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.ADD_STEP_LINK_ID);

        String stepName1 = "Show Property Categories";
        String stepName2 = "Show Buying Options";

        addStepName(stepName1);
        Thread.sleep(2000);
        addStepName(stepName2);
        Thread.sleep(2000);

        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.ADD_STEP_LINK_ID);

        WebElement webElement = driver.findElement(By.id(JourneysPageConstants.STEP_LIST_ID)).findElement(By.tagName(HTMLConstants.DIV));
        List<WebElement> stepList = webElement.findElements(By.tagName(HTMLConstants.ANCHOR));

        boolean flag = false;
        for (int i = 0; i < stepList.size() - 1; i++) {
            WebElement element = stepList.get(i);
            String stepName = element.findElement(By.tagName(HTMLConstants.DIV)).getText();
            if (StringUtils.equals(stepName, stepName1) || StringUtils.equals(stepName, stepName1)) {
                flag = true;
                break;
            }
        }


        assertTrue(stepList.size() > 1);
        assertEquals(flag, true);

    }

    /**
     * This test is meant for adding an init function to the custom journey
     * @throws InterruptedException
     */
    @Test(priority = 6)
    public void testInitFunctionAddition() throws InterruptedException {
        Reporter.log("Executing testcase:  testInitFunctionAddition", true);

        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.JOURNEY_SETTINGS_LINK_ID);

        driver.findElement(By.id(JourneysPageConstants.JOURNEY_SETTINGS_LINK_ID)).click();
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.CREATE_FUNC_NAV_LINK_ID);
        driver.findElement(By.id(JourneysPageConstants.CREATE_FUNC_NAV_LINK_ID)).click();
        SeleniumUtils.waitForElementLoadById(driver, CloudFunctionConstants.NEW_FUNC_BUTTON_ID);
        DeveloperUtils.createNewDummyFunction(driver, DUMMY_INIT_FUNCTION);
        SeleniumUtils.waitForElementLoadById(driver, CloudFunctionConstants.NEW_FUNC_BUTTON_ID);
        SeleniumUtils.navigateBack(driver);

        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.JOURNEY_SETTINGS_LINK_ID);
        driver.findElement(By.id(JourneysPageConstants.JOURNEY_SETTINGS_LINK_ID)).click();


        WebElement functionIdentifier = driver
                .findElement(By.className(JourneysPageConstants.INIT_FUNCTION_DROPDOWN_CLASS));
        functionIdentifier.click();

        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.INIT_FUNCTION_OPTION_ID);

        List<WebElement> functionList = driver.findElements(By.id(JourneysPageConstants.INIT_FUNCTION_OPTION_ID));

        for (WebElement function : functionList) {
            if (StringUtils.equals(function.getText(), DUMMY_INIT_FUNCTION)) {
                function.click();
                Thread.sleep(2000);
                break;
            }
        }

        SeleniumUtils.waitForImplicitPageLoad(driver, 15);
        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.JOURNEY_SETTINGS_LINK_ID, 30);

        driver.findElement(By.id(JourneysPageConstants.JOURNEY_SETTINGS_LINK_ID)).click();
        String initFunction = driver
                .findElement(By.className(JourneysPageConstants.INIT_FUNCTION_DROPDOWN_CLASS)).getText();

        assertEquals(initFunction, DUMMY_INIT_FUNCTION);

    }

    /**
     * This test is meant for adding response to steps in the custom journey
     * @throws InterruptedException
     */
    @Test(priority = 7)
    public void testResponseAdditionToSteps() throws InterruptedException {
        Reporter.log("Executing testcase:  testResponseAdditionToSteps", true);

        SeleniumUtils.refreshUrl(driver);

        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.JOURNEY_SETTINGS_LINK_ID, 30);

        goToCustomStep();
        Thread.sleep(2000);

        WebElement responseTimeline = driver.findElement(By.className(JourneysPageConstants.RESPONSE_TIMELINE_CLASS));
        List<WebElement> responseTypeList = responseTimeline.findElements(By.id(JourneysPageConstants.RESPONSE_TYPE_BUTTON_ID));

        responseTypeList.get(4).click();

        WebElement dropdown = driver.findElement(By.className(JourneysPageConstants.RESPONSE_TIMELINE_CLASS))
                .findElement(By.className(JourneysPageConstants.FUNCTION_SELECT_DROPDOWN_CLASS));
        dropdown.click();

        List<WebElement> functionList = driver.findElements(By.id(JourneysPageConstants.FUNCTION_OPTION_ID));

        for (WebElement function : functionList) {
            if (StringUtils.equals(function.getText(), DUMMY_INIT_FUNCTION)) {
                function.click();
                Thread.sleep(2000);
                break;
            }
        }


        SeleniumUtils.waitForImplicitPageLoad(driver, 10);
        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.JOURNEY_SETTINGS_LINK_ID);

        goToCustomStep();
        Thread.sleep(2000);

        String selectedFunction = driver.findElement(By.className(JourneysPageConstants.RESPONSE_TIMELINE_CLASS))
                .findElement(By.className(JourneysPageConstants.FUNCTION_SELECT_DROPDOWN_CLASS)).getText();

        assertEquals(selectedFunction, DUMMY_INIT_FUNCTION);

    }

    /**
     * This test is meant for deleting the custom journey
     * @throws InterruptedException
     */
    @Test(priority = 8)
    public void testDeleteCustomJourney() throws InterruptedException {
        Reporter.log("Executing testcase:  testDeleteJourney", true);

        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.JOURNEY_DELETE_LINK_ID);

        driver.findElement(By.id(JourneysPageConstants.JOURNEY_DELETE_LINK_ID)).click();
        SeleniumUtils.waitForImplicitPageLoad(driver, 20);

        List<WebElement> buttonList = DeveloperUtils.getButtonList(driver);
        SeleniumUtils.waitForImplicitPageLoad(driver, 20);
        DeveloperUtils.clickOKButton(buttonList);
        Thread.sleep(2000);
        boolean journeyFoundFlag = validateJourneyCreation(DUMMY_TEST_JOURNEY_NAME);

        assertEquals(journeyFoundFlag, false);


    }


    private void goToCustomStep() {
        WebElement webElement = driver.findElement(By.id(JourneysPageConstants.STEP_LIST_ID)).findElement(By.tagName(HTMLConstants.DIV));
        List<WebElement> stepList = webElement.findElements(By.tagName(HTMLConstants.ANCHOR));
        stepList.get(0).click();
    }


    private void addCategory(String categoryName) {

        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.CATEGORY_LISTING_BUTTON_ID);
        driver.findElement(By.id(JourneysPageConstants.CATEGORY_LISTING_BUTTON_ID)).click();
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.CATEGORY_NAME_ID);
        driver.findElement(By.id(JourneysPageConstants.CATEGORY_NAME_ID)).sendKeys(categoryName);
        driver.findElement(By.id(JourneysPageConstants.CATEGORY_ADD_BUTTON_ID)).click();
    }


    private boolean switchToCustomCategory(String categoryName) throws InterruptedException {

        boolean categoryFound = false;

        driver.findElement(By.id(JourneysPageConstants.CATEGORY_LISTING_BUTTON_ID)).click();
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.CATEGORY_LINK_ID);
        List<WebElement> categories = driver.findElements(By.id(JourneysPageConstants.CATEGORY_LINK_ID));

        for (WebElement category : categories) {
            if (StringUtils.equals(category.getText(), categoryName)) {
                category.click();
                categoryFound = true;
                break;
            }
        }
        return categoryFound;
    }

    private boolean validateJourneyCreation(String journeyName) {
        List<WebElement> journeysList = driver.findElements(By.className(JourneysPageConstants.JOURNEY_LINK_ID));

        boolean journeyFoundFlag = false;
        for (WebElement journey : journeysList) {
            if (StringUtils.equals((journey.findElement(By.tagName(HTMLConstants.DIV)).getText()), journeyName)) {
                journeyFoundFlag = true;
                break;
            }
        }
        return journeyFoundFlag;
    }

    private String createJourneyAndReturnCategory(String journeyName) {

        driver.findElement(By.id(JourneysPageConstants.CREATE_JOURNEY_BUTTON_ID)).click();
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.IMPORT_JOURNEY_BUTTON_ID);

        driver.findElement(By.id(JourneysPageConstants.JOURNEY_NAME_ID)).sendKeys(journeyName);
        driver.findElement(By.id(JourneysPageConstants.JOURNEY_DESC_ID)).sendKeys(journeyName);
        String journeyCategory = driver.findElement(By.id(JourneysPageConstants.JOURNEY_CATEGORY_ID)).getAttribute(HTMLConstants.VALUE);
        driver.findElement(By.id(JourneysPageConstants.CREATE_CONFIRM_BUTTON_ID)).click();
        try {
            Thread.sleep(2000);
        } catch (Exception e) {
            //TODO: log something
        }

        SeleniumUtils.waitForImplicitPageLoad(driver, 15);
        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForImplicitPageLoad(driver, 15);
        return journeyCategory;
    }

    private void switchToCustomJourney() {
        List<WebElement> journeysList = driver.findElements(By.className(JourneysPageConstants.JOURNEY_LINK_ID));

        for (WebElement journey : journeysList) {
            if (StringUtils.equals((journey.findElement(By.tagName(HTMLConstants.DIV)).getText()), DUMMY_TEST_JOURNEY_NAME)) {
                journey.click();
                break;
            }
        }
    }


    private void addStepName(String stepName1) {
        SeleniumUtils.refreshUrl(driver);
        SeleniumUtils.waitForElementLoadById(driver, JourneysPageConstants.ADD_STEP_LINK_ID);
//        SeleniumUtils.waitForImplicitPageLoad(driver, 15);
        driver.findElement(By.id(JourneysPageConstants.ADD_STEP_LINK_ID)).click();
        SeleniumUtils.waitForElementLoadByClassName(driver, JourneysPageConstants.STEP_NAME_ID);
        driver.findElement(By.className(JourneysPageConstants.STEP_NAME_ID)).sendKeys(stepName1);
        driver.findElement(By.id(JourneysPageConstants.CREATE_STEP_BUTTON_ID)).click();
    }


}
