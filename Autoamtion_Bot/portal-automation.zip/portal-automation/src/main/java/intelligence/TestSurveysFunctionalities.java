package intelligence;

import common.setup.IntelligenceNavigationSetup;

public class TestSurveysFunctionalities extends IntelligenceNavigationSetup {

}
