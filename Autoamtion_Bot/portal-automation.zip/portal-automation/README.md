# portal-automation

This repository is meant to hold automation test cases for the portal.
This is a maven-built project having all the required dependencies in the pom.xml file.

The testng.xml is the file where we need to add classes where new test cases would be created.
The entire test suite can be executed using the maven command 'mvn test'. This executes the test cases as and how mentioned in the testng.xml file.

The pre-requisites (for now) before executing the test cases is that- 
 1. A test bot should be present (created manually)
 2. Need to go to the bot configuration tab for the test bot, and then add a bot title, change the cloud functions version to V1 and save.
Later, it should be automated by code, to be included in the DeveloperNavigationSetup class.
